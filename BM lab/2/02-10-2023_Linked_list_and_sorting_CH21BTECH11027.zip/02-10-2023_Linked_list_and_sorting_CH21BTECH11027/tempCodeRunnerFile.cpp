            case 3:
                cout<<"search "<<endl;
                cout<<"Enter value"<<endl;
                cin>>value;
                search(head,value);
                break;
            case 4:
                cout<<"display "<<endl;
                display(head);
                cout<<endl;
